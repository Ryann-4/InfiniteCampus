function padlet() {
    window.open("https://padlet.com/newsomr95/chat-room-br2tjbusbebezr2n");
}
function converter() {
    window.open("https://spotidownloader.com/en")
}
function puter() {
    window.open("https://puter.com");
}
function exploit() {
    alert('When You Type Stuff In You Will Still See It In Your History PS Type In The Box That Says "null"') 
    window.open("https://sw.mzdy.com/!")
}
function thumbnail() {
    window.open("https://tagmp3.net/")
}